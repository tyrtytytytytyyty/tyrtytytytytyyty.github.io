// Simple local retrieval: BM25 over chunks of knowledge/**/*.md|txt. No network, no embeddings.
import fs from "node:fs";
import path from "node:path";

export interface Chunk { file: string; heading: string; text: string; tf: Map<string, number>; len: number }
const STOP = new Set("a an and are as at be but by can do does for from had has have how i if in into is it its me my of on or our so than that the their them then there these they this to up was we were what when where which who why will with you your about after all also any been being both could did get got just more most much not now only other out over should some such too use used using very would long much many need needs make take want like know thing things way best good someone something".split(" "));

export function tokenize(s: string): string[] {
  const out: string[] = [];
  for (let w of s.toLowerCase().match(/[a-z0-9]+/g) || []) {
    if (w.length < 2 || STOP.has(w)) continue;
    if (w.length > 4 && w.endsWith("ies")) w = w.slice(0, -3) + "y";
    else if (w.length > 5 && w.endsWith("ing")) w = w.slice(0, -3);
    else if (w.length > 4 && w.endsWith("es")) w = w.slice(0, -2);
    else if (w.length > 3 && w.endsWith("s") && !w.endsWith("ss")) w = w.slice(0, -1);
    out.push(w);
  }
  return out;
}

function walk(dir: string, acc: string[] = []): string[] {
  let ents: fs.Dirent[] = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return acc; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, acc);
    else if (/\.(md|txt)$/i.test(e.name) && !/^readme/i.test(e.name)) acc.push(p);
  }
  return acc;
}

function splitText(heading: string, body: string, max = 1100): [string, string][] {
  const paras = body.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const res: [string, string][] = []; let cur = "";
  for (const p of paras) {
    if (cur && cur.length + p.length > max) { res.push([heading, cur]); cur = ""; }
    cur += (cur ? "\n\n" : "") + p;
  }
  if (cur) res.push([heading, cur]);
  return res;
}

export class Index {
  chunks: Chunk[] = []; df = new Map<string, number>(); avg = 1; files: string[] = [];
  constructor(public root: string) { this.build(); }
  build() {
    this.chunks = []; this.df.clear(); this.files = [];
    for (const f of walk(this.root).sort()) {
      let raw = ""; try { raw = fs.readFileSync(f, "utf8"); } catch { continue; }
      const rel = path.relative(this.root, f).split(path.sep).join("/");
      this.files.push(rel);
      raw = raw.replace(/\r\n/g, "\n");
      const title = (raw.match(/^#\s+(.+)$/m) || [, rel])[1] as string;
      const parts = raw.split(/^(?=##?\s)/m);
      for (const part of parts) {
        const m = part.match(/^#{1,2}\s+(.+)\n?/);
        const heading = m ? m[1].trim() : title;
        if (/^sources?$/i.test(heading)) continue;
        const body = m ? part.slice(m[0].length) : part;
        for (const [h, t] of splitText(heading, body)) {
          if (t.trim().length < 20) continue;
          const toks = [...tokenize(rel.replace(/[-_.]/g, " ")), ...tokenize(title), ...tokenize(h), ...tokenize(h), ...tokenize(t)];
          const tf = new Map<string, number>(); for (const w of toks) tf.set(w, (tf.get(w) || 0) + 1);
          this.chunks.push({ file: rel, heading: h, text: t, tf, len: toks.length });
        }
      }
    }
    for (const c of this.chunks) for (const w of c.tf.keys()) this.df.set(w, (this.df.get(w) || 0) + 1);
    this.avg = this.chunks.reduce((a, c) => a + c.len, 0) / Math.max(1, this.chunks.length);
  }
  search(q: string, k = 3): { chunk: Chunk; score: number }[] {
    const qs = [...new Set(tokenize(q))]; if (!qs.length || !this.chunks.length) return [];
    const n = this.chunks.length, k1 = 1.4, b = 0.75;
    const scored = this.chunks.map((chunk) => {
      let s = 0, hit = 0;
      for (const w of qs) {
        const f = chunk.tf.get(w); if (!f) continue;
        const df = this.df.get(w) || 0, idf = Math.log(1 + (n - df + 0.5) / (df + 0.5));
        s += idf * ((f * (k1 + 1)) / (f + k1 * (1 - b + (b * chunk.len) / this.avg)));
        hit++;
      }
      s *= 0.4 + 0.6 * (hit / qs.length); // reward chunks that match more of the question's words
      return { chunk, score: s };
    }).filter((x) => x.score > 0).sort((a, b2) => b2.score - a.score);
    if (!scored.length || scored[0].score < 1.5) return [];
    const top = scored.filter((x) => x.score >= scored[0].score * 0.7).slice(0, k);
    // safety first: if the best file has a warning section, always hand it to the model too
    const w = scored.find((x) => x.chunk.file === top[0].chunk.file && /^warning/i.test(x.chunk.heading) && !top.includes(x));
    if (w) top.push(w);
    return top;
  }
}
