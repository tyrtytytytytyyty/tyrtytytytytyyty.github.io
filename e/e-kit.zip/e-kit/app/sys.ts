import os from "node:os";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

export const GB = 1024 ** 3;
export const plat = process.platform; // darwin | linux | win32
export const archName = process.arch === "arm64" ? "arm64" : "x64";
export const osKey = plat === "win32" ? "windows" : plat;

export function kitHome(): string {
  if (process.env.E_HOME) return path.resolve(process.env.E_HOME);
  // compiled binary lives in <kit>/bin/
  const exe = path.dirname(process.execPath);
  if (path.basename(exe) === "bin") return path.dirname(exe);
  return path.resolve(import.meta.dir, "..");
}

export function ram(): { total: number; free: number } {
  const total = os.totalmem();
  let free = os.freemem();
  try {
    if (plat === "darwin") {
      const t = spawnSync("vm_stat", { encoding: "utf8" }).stdout || "";
      const ps = Number((t.match(/page size of (\d+)/) || [])[1] || 16384);
      const g = (k: string) => Number((t.match(new RegExp(`${k}:\\s+(\\d+)`)) || [])[1] || 0);
      const pages = g("Pages free") + g("Pages inactive") + g("Pages speculative") + g("Pages purgeable");
      if (pages > 0) free = pages * ps;
    } else if (plat === "linux") {
      const m = fs.readFileSync("/proc/meminfo", "utf8").match(/MemAvailable:\s+(\d+) kB/);
      if (m) free = Number(m[1]) * 1024;
    }
  } catch {}
  return { total, free: Math.min(free, total) };
}

export function osLabel(): string {
  try {
    if (plat === "darwin") return "macOS " + (spawnSync("sw_vers", ["-productVersion"], { encoding: "utf8" }).stdout || "").trim();
    if (plat === "win32") return Number(os.release().split(".")[2]) >= 22000 ? "Windows 11" : "Windows 10";
    const m = fs.readFileSync("/etc/os-release", "utf8").match(/^PRETTY_NAME="?([^"\n]+)/m);
    if (m) return m[1];
  } catch {}
  return plat === "linux" ? "Linux" : os.platform();
}

export function cores(): number { return (os as any).availableParallelism?.() ?? os.cpus().length; }

export function diskFree(dir: string): number | null {
  try { const s: any = (fs as any).statfsSync(dir); return Number(s.bavail) * Number(s.bsize); } catch { return null; }
}
export const fmtGB = (b: number) => (b / GB >= 10 ? (b / GB).toFixed(0) : (b / GB).toFixed(1)) + " GB";
export const driveLabel = (dir: string) => (plat === "win32" ? path.parse(dir).root : dir);

export interface Tier { id: string; tag: string; name: string; params: string; size: number; blurb: string; sub: string; needTotal: number; needFree: number; needLabel: string }
export const TIERS: Tier[] = [
  { id: "tiny", tag: "gemma3:1b", name: "tiny", params: "~1B", size: 0.81, blurb: "runs on anything (8 GB RAM)", sub: "fast, a little forgetful", needTotal: 4, needFree: 1.5, needLabel: "4 GB" },
  { id: "default", tag: "llama3.2:3b", name: "default", params: "~3B", size: 2.0, blurb: "best for most laptops (8 GB RAM)", sub: "good chat, decent code", needTotal: 8, needFree: 3, needLabel: "8 GB" },
  { id: "big", tag: "llama3.1:8b", name: "big", params: "~8B", size: 4.9, blurb: "if you have 16 GB+ RAM", sub: "smartest, slower on old CPUs", needTotal: 16, needFree: 8, needLabel: "16 GB" },
  { id: "huge", tag: "gemma3:27b", name: "huge", params: "~27B", size: 17, blurb: "if you have 32 GB+ RAM", sub: "near cloud-level, needs a strong machine", needTotal: 32, needFree: 20, needLabel: "32 GB" },
];
export function fits(t: Tier, r: { total: number; free: number }): { ok: boolean; why: string } {
  if (process.env.E_FORCE === "1") return { ok: true, why: "" };
  if (r.total / GB < t.needTotal - 0.6) return { ok: false, why: `needs ${t.needLabel} RAM` }; // 0.6: "8 GB" Macs report ~8.0, some PCs ~7.4
  if (r.free / GB < t.needFree) return { ok: false, why: `needs ~${t.needFree} GB free` };
  return { ok: true, why: "" };
}
export function recommended(r: { total: number; free: number }): Tier {
  const gb = r.total / GB;
  if (gb < 6.5) return TIERS[0];
  if (gb >= 32 && fits(TIERS[2], r).ok) return TIERS[2];
  return fits(TIERS[1], r).ok ? TIERS[1] : TIERS[0];
}
