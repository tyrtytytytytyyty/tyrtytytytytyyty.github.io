import fs from "node:fs";
import path from "node:path";
import { spawn, ChildProcess } from "node:child_process";
import { kitHome, osKey, archName, plat } from "./sys";

export const PORT = Number(process.env.E_PORT || 11435);
export const BASE = `http://127.0.0.1:${PORT}`;

/** models already on the drive (manifest files), so we know whether the server needs the internet at all */
export function modelsOnDisk(home: string): string[] {
  const root = path.join(home, "models", "manifests"), res: string[] = [];
  const walk = (d: string, rel: string[]) => {
    let ents: fs.Dirent[] = []; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of ents) e.isDirectory() ? walk(path.join(d, e.name), [...rel, e.name]) : res.push(rel.slice(2).join("/") + ":" + e.name);
  };
  walk(root, []); return res;
}

export function findOllama(home: string): string | null {
  const d = path.join(home, "bin", `ollama-${osKey}-${archName}`);
  for (const rel of ["ollama", "ollama.exe", "bin/ollama", "bin/ollama.exe"]) {
    const p = path.join(d, rel);
    if (fs.existsSync(p) && fs.statSync(p).isFile()) return p;
  }
  return null;
}

export class Server {
  proc: ChildProcess | null = null;
  home = kitHome();
  logFile = path.join(this.home, "e.log");
  owned = false;
  online = false;
  async up(): Promise<boolean> {
    try { const r = await fetch(`${BASE}/api/version`, { signal: AbortSignal.timeout(800) }); return r.ok; } catch { return false; }
  }
  async start(online = false): Promise<void> {
    this.online = online;
    if (await this.up()) return; // an e server from another window is already running; reuse it
    const exe = findOllama(this.home);
    if (!exe) throw new Error("E-RUNTIME-01 runtime not found (run e.sh / e.bat again to finish setup)");
    const models = path.join(this.home, "models");
    const data = path.join(this.home, "data", "home");
    fs.mkdirSync(models, { recursive: true }); fs.mkdirSync(data, { recursive: true });
    const fd = fs.openSync(this.logFile, "a");
    this.proc = spawn(exe, ["serve"], {
      stdio: ["ignore", fd, fd], windowsHide: true,
      env: {
        ...process.env, OLLAMA_HOST: `127.0.0.1:${PORT}`, OLLAMA_MODELS: models, HOME: data, USERPROFILE: data,
        OLLAMA_NO_CLOUD: "1", NO_PROXY: "127.0.0.1,localhost",
        // offline mode: even ollama's own background checks cannot leave the machine. online mode is used only while downloading a model.
        ...(online ? {} : { HTTP_PROXY: "http://127.0.0.1:9", HTTPS_PROXY: "http://127.0.0.1:9", ALL_PROXY: "http://127.0.0.1:9", http_proxy: "http://127.0.0.1:9", https_proxy: "http://127.0.0.1:9" }), OLLAMA_KEEP_ALIVE: "30m", OLLAMA_MAX_LOADED_MODELS: "1", OLLAMA_NUM_PARALLEL: "1", OLLAMA_CONTEXT_LENGTH: "4096",
      },
    });
    this.owned = true;
    this.proc.on("error", (e) => { fs.appendFileSync(this.logFile, `spawn error: ${e}\n`); });
    for (let i = 0; i < 100; i++) {
      if (await this.up()) return;
      if (this.proc.exitCode !== null) break;
      await new Promise((r) => setTimeout(r, 200));
    }
    throw new Error("E-RUNTIME-02 the local model server did not start (see e.log)");
  }
  async restart(online: boolean): Promise<void> {
    if (!this.owned || online === this.online) return;
    this.stop();
    for (let i = 0; i < 50 && (await this.up()); i++) await new Promise((r) => setTimeout(r, 200));
    this.proc = null; this.owned = false;
    await this.start(online);
  }
  stop() {
    if (this.proc && this.owned && this.proc.exitCode === null) {
      try { this.proc.kill(plat === "win32" ? undefined : "SIGTERM"); } catch {}
    }
  }
  async unload(model: string) {
    try { await fetch(`${BASE}/api/generate`, { method: "POST", body: JSON.stringify({ model, keep_alive: 0 }), signal: AbortSignal.timeout(5000) }); await new Promise((r) => setTimeout(r, 1200)); } catch {}
  }
  async tags(): Promise<{ name: string; size: number }[]> {
    const r = await fetch(`${BASE}/api/tags`); const j: any = await r.json(); return j.models || [];
  }
  async pull(model: string, onProg: (done: number, total: number, status: string) => void): Promise<void> {
    const r = await fetch(`${BASE}/api/pull`, { method: "POST", body: JSON.stringify({ model, stream: true }) });
    if (!r.ok || !r.body) throw new Error(`E-NET-02 pull failed (${r.status})`);
    for await (const o of ndjson(r.body)) {
      if (o.error) throw new Error("E-NET-01 " + o.error);
      onProg(o.completed || 0, o.total || 0, o.status || "");
    }
  }
  async *chat(model: string, messages: { role: string; content: string }[], signal: AbortSignal): AsyncGenerator<any> {
    const r = await fetch(`${BASE}/api/chat`, {
      method: "POST", signal,
      body: JSON.stringify({ model, messages, stream: true, keep_alive: "30m", options: { num_ctx: 4096, temperature: 0.2 } }),
    });
    if (!r.ok || !r.body) throw new Error(`E-CHAT-01 ${r.status} ${await r.text().catch(() => "")}`);
    for await (const o of ndjson(r.body)) { if (o.error) throw new Error("E-CHAT-02 " + o.error); yield o; }
  }
}

async function* ndjson(body: ReadableStream<Uint8Array>): AsyncGenerator<any> {
  const dec = new TextDecoder(); let buf = "";
  for await (const chunk of body as any) {
    buf += dec.decode(chunk, { stream: true });
    let i: number;
    while ((i = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (line) { try { yield JSON.parse(line); } catch {} }
    }
  }
  if (buf.trim()) { try { yield JSON.parse(buf); } catch {} }
}
