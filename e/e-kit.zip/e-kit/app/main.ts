// e - offline AI in the terminal. Zero installs: this file is compiled to one binary per OS (bun build --compile).
import fs from "node:fs";
import path from "node:path";
import {
  mode, utf8, isTTY, C, G, RST, SGR_BG, fg, bg, paint, dim, muted, accent, hot, grad, gradText, box, vlen, padR, termSize, out, hideCursor, showCursor, log,
} from "./ui";
import { frame, buildE, FREEZE_X, FREEZE_Y, BIG, SMALL, Size } from "./logo";
import { Index } from "./rag";
import { Server, modelsOnDisk } from "./ollama";
import { Input } from "./input";
import { TIERS, Tier, ram, fits, recommended, osLabel, cores, diskFree, fmtGB, driveLabel, kitHome, GB } from "./sys";

const VERSION = "1.0.0";
const args = process.argv.slice(2);
const has = (f: string) => args.includes(f);
const opt = (f: string) => { const i = args.indexOf(f); return i >= 0 ? args[i + 1] : undefined; };
const HOME = kitHome();
const CFG = path.join(HOME, "data", "config.json");
const LOG = path.join(HOME, "e.log");
const E_DIGITS = "2.718281828459045235360287";
const anim = isTTY && mode !== "none" && !has("--no-anim") && !process.env.E_NO_ANIM && process.env.TERM !== "dumb";
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function cfg(): any { try { return JSON.parse(fs.readFileSync(CFG, "utf8")); } catch { return {}; } }
function saveCfg(o: any) { try { fs.mkdirSync(path.dirname(CFG), { recursive: true }); fs.writeFileSync(CFG, JSON.stringify({ ...cfg(), ...o }, null, 2)); } catch {} }

// ---------- terminal lifecycle ----------
let osc = false;
function termInit() {
  if (!isTTY || mode === "none" || process.env.E_NO_BG === "1") return;
  if (mode === "true") { out("\x1b]11;#0B0806\x07\x1b]10;#F6EBDD\x07"); osc = true; }
  else if (SGR_BG) out(bg(C.bg) + fg(C.fg) + "\x1b[2J\x1b[H");
}
const srv = new Server();
let input: Input | null = null;
let cleaned = false;
function cleanup() {
  if (cleaned) return; cleaned = true;
  srv.stop(); showCursor();
  if (osc) out("\x1b]111\x07\x1b]110\x07");
  if (isTTY) out(mode === "none" ? "" : "\x1b[0m" + (SGR_BG ? "\x1b[2J\x1b[H" : ""));
  try { input?.close(); } catch {}
}
function quit(code = 0): never { cleanup(); process.exit(code); }
process.on("exit", cleanup);
for (const s of ["SIGTERM", "SIGHUP"] as const) process.on(s, () => quit(130));
process.on("SIGINT", () => quit(130));
process.on("uncaughtException", (e) => { log(LOG, "uncaught: " + (e as Error).stack); showErr("something went wrong", ["e hit an unexpected problem and stopped.", "details were saved to e.log on the drive."], "E-BUG-01"); quit(1); });

// ---------- boxes ----------
function width(): number { return Math.max(40, termSize().cols - 2); } // full terminal width (his ask, 11/01)
function showErr(title: string, body: string[], code: string, question = "") {
  const inner = width();
  const wrapLine = (s: string): string[] => {
    const lead = s.match(/^\s*/)![0], words = s.trim().split(/\s+/), res: string[] = []; let cur = lead;
    for (const wd of words) { if (cur.trim() && vlen(cur) + 1 + wd.length > inner - 4) { res.push(cur); cur = lead + "  "; } cur += (cur.trim() ? " " : "") + wd; }
    res.push(cur); return res;
  };
  const lines = ["", ...body.flatMap((b) => wrapLine(b).map((x) => "   " + x)), "", "   nothing was deleted. your files are fine.", ""];
  out("\n" + box(lines, inner, title, true).join("\n") + "\n");
  out(" " + gradText("[x]") + " " + code + (question ? "  " + question : "") + "\n");
}

// ---------- splash ----------
function splashLines(sz: Size | null, ay: number, ax: number, st: { runtime: string }, compact = false): string[] {
  const inner = width(), pad = (s: string) => "   " + s;
  const L: string[] = [""];
  if (sz) { const fr = frame(ay, ax, sz); const left = " ".repeat(Math.max(0, Math.floor((inner - sz.cols) / 2))); for (const r of fr) L.push(left + r); }
  else L.push("   " + gradText("(e)") + "  offline ai on a stick");
  if (compact) { L.push(""); return box(L, inner, "e " + G.dot + " v" + VERSION); } // small window: logo only
  const r = ram();
  const rt = st.runtime === "ready" ? "ollama  " + hot("[ok]") : st.runtime === "starting" ? dim("ollama  starting...") : gradText("[x]") + " runtime failed";
  const df = diskFree(HOME);
  L.push("", pad(dim("e = " + E_DIGITS + "...")), pad(dim("offline ai on a usb stick. no account.")), "",
    pad(dim("system   ") + `${osLabel()} ${G.dot} ${fmtGB(r.total)} RAM ${G.dot} ${cores()} cores`),
    pad(dim("drive    ") + `${driveLabel(HOME)}${df !== null ? " " + G.dot + " " + fmtGB(df) + " free" : ""}`),
    pad(dim("runtime  ") + rt),
    pad(dim("network  ") + "not needed after setup"), "");
  return box(L.map((l) => l), inner, "e " + G.dot + " v" + VERSION);
}
async function splash(ready: Promise<void>, st: { runtime: string }): Promise<void> {
  buildE();
  const { cols, rows } = termSize();
  // scale the e to fill the window: as many rows as fit under the info lines, keeping BIG's aspect
  const fitW = Math.floor((width() - 6) / (BIG.cols / BIG.rows));
  let r = Math.min(rows - 17, fitW), compact = false;
  if (r < 12) { compact = true; r = Math.min(rows - 5, fitW); } // e.g. the default 80x24 Terminal
  const sz: Size | null = cols < 34 || r < 10 ? null : { rows: r, cols: Math.round(r * BIG.cols / BIG.rows), sc: BIG.sc * r / BIG.rows };
  if (!anim) {
    await ready.catch(() => {});
    out(splashLines(cols < 34 ? null : sz ?? SMALL, FREEZE_Y, FREEZE_X, st).join("\n") + "\n");
    return;
  }
  hideCursor();
  let go = false;
  const kp = input!.key().then((k) => { if (k === "\x03") quit(130); go = true; });
  void kp;
  const t0 = Date.now(); let n = 0, first = true;
  const tip = " " + muted("tip: ctrl+c twice to quit " + G.dot + " /models to switch") + "   " + accent("press any key");
  while (!go) {
    const s = (Date.now() - t0) / 1000;
    const L = splashLines(sz, FREEZE_Y + s * 0.55, FREEZE_X + Math.sin(s * 0.5) * 0.08, st, compact); // ~11 s per turn
    L.push(tip);
    out("\x1b[?2026h" + (first ? "" : `\x1b[${n}A`) + L.map((l) => l + "\x1b[K").join("\n") + "\n\x1b[?2026l");
    n = L.length; first = false;
    await sleep(42);
  }
  showCursor();
}

// ---------- model picker ----------
function pickerLines(sel: number, installed: Set<string>, r: { total: number; free: number }): string[] {
  const rec = recommended(r), w = Math.max(40, termSize().cols - 2);
  const L: string[] = [" pick a brain" + " ".repeat(Math.max(1, w - 13 - 18)) + dim("arrows + enter"), " " + muted(G.h.repeat(w - 1))];
  TIERS.forEach((t, i) => {
    const f = fits(t, r), isSel = i === sel;
    const head = `${isSel ? ">" : " "} ${t.name.padEnd(8)} ${t.params.padEnd(4)} ${(t.size.toFixed(1) + " GB").padEnd(7)} ${t.blurb}`;
    const tags = (t === rec && f.ok ? "  * recommended" : "") + (installed.has(t.tag) ? "  [installed]" : "") + (f.ok ? "" : `  (${f.why})`);
    const row1 = "  " + head + tags, row2 = "    " + t.sub;
    if (isSel) { L.push(bg(C.panel) + fg(C.accent) + padR(row1, w) + RST, bg(C.panel) + fg(C.dim) + padR(row2, w) + RST); }
    else if (!f.ok) { L.push(muted(row1), muted(row2)); }
    else { L.push(row1.replace(/\* recommended/, hot("* recommended")), dim(row2)); }
    L.push("");
  });
  L.push(" " + muted(G.h.repeat(w - 1)));
  const ok = TIERS.filter((t) => fits(t, r).ok).length;
  L.push(" " + dim(`your machine: ${fmtGB(r.total)} RAM, ${fmtGB(r.free)} free  ->  ` + (ok === TIERS.length ? "all of them will fit" : ok === 0 ? "none of these will fit right now" : `${ok} of ${TIERS.length} will fit`)));
  L.push(" " + dim("no internet after download. you can unplug and go."));
  return L;
}
async function pick(installed: Set<string>): Promise<Tier | null> {
  const r = ram();
  let sel = Math.max(0, TIERS.indexOf(recommended(r)));
  if (!input!.tty) return recommended(r);
  for (;;) {
    let n = 0;
    const draw = (first: boolean) => { const L = pickerLines(sel, installed, r); out((first ? "" : `\x1b[${n}A`) + L.map((l) => l + "\x1b[K").join("\n") + "\n"); n = L.length; };
    out("\n"); hideCursor(); draw(true);
    for (;;) {
      const k = await input!.key();
      if (k === null || k === "\x03") { showCursor(); return null; }
      if (k === "\x1b[A" || k === "k") sel = (sel + TIERS.length - 1) % TIERS.length;
      else if (k === "\x1b[B" || k === "j") sel = (sel + 1) % TIERS.length;
      else if (/^[1-9]$/.test(k) && Number(k) <= TIERS.length) sel = Number(k) - 1;
      else if (k === "\r" || k === "\n") break;
      draw(false);
    }
    showCursor();
    const t = TIERS[sel], f = fits(t, r);
    if (f.ok) return t;
    const totalShort = r.total / GB < t.needTotal - 0.6;
    const alt = TIERS.filter((x) => x.size < t.size && r.total / GB >= x.needTotal - 0.6).pop();
    const canForce = !totalShort;
    showErr("not enough memory", [
      totalShort ? `the ${t.params} brain needs ${t.needLabel} RAM. you have ${fmtGB(r.total)}.` : `the ${t.params} brain needs ~${t.needFree} GB free. you have ${fmtGB(r.free)} free.`,
      "", "try instead:",
      ...(totalShort ? [] : ["  1. close your browser and run again"]),
      alt ? `  ${totalShort ? 1 : 2}. pick the ${alt.params} model (needs ~${alt.needFree} GB)${" ".repeat(3)}[recommended]` : "  - this computer is too small for any of the models",
    ], "E-RAM-01", "pick another model? (y/n)" + (canForce ? "  or f = run it anyway" : "") + " ");
    for (;;) {
      const a = await input!.key();
      if (a === null || a === "\x03" || a === "n" || a === "N") { out("\n"); return null; }
      if (canForce && (a === "f" || a === "F")) { out("\n"); return t; }
      if (a === "y" || a === "Y" || a === "\r") break;
    }
  }
}

// ---------- download ----------
async function ensureModel(t: Tier): Promise<boolean> {
  let have = new Set<string>(); try { have = new Set((await srv.tags()).map((m) => m.name)); } catch {}
  if (have.has(t.tag) || have.has(t.tag + ":latest")) return true;
  const df = diskFree(path.join(HOME, "models"));
  if (df !== null && df < (t.size + 0.3) * GB) {
    showErr("not enough space on the drive", [`${t.params} needs about ${t.size.toFixed(1)} GB; this drive has ${fmtGB(df)} free.`, "", "free some space or pick a smaller brain."], "E-DISK-01");
    return false;
  }
  await srv.restart(true); // the one moment the server is allowed to reach the internet
  out(`\n ${accent("downloading " + t.tag)} ${dim("(one time, needs internet)")}\n`);
  const w = 28; let last = 0, lastPct = -10, lt = Date.now(), lb = 0, speed = 0;
  try {
    await srv.pull(t.tag, (done, total, status) => {
      if (!total) { if (!anim && status !== "success" && Date.now() - last > 2000) { out(" " + status + "\n"); last = Date.now(); } return; }
      const now = Date.now(); if (now - lt > 700) { speed = ((done - lb) / ((now - lt) / 1000)) / 1e6; lt = now; lb = done; }
      const p = done / total;
      if (anim) {
        if (now - last < 100 && p < 1) return; last = now;
        const f = Math.round(p * w); let bar = "";
        for (let i = 0; i < w; i++) bar += i < f ? grad(i / (w - 1)) + G.fill : fg(C.muted) + G.empty;
        out(`\r\x1b[K ${bar}${RST} ${String(Math.round(p * 100)).padStart(3)}%  ${dim((done / 1e6).toFixed(0) + " / " + (total / 1e6).toFixed(0) + " MB" + (speed ? "  " + speed.toFixed(1) + " MB/s" : ""))}`);
      } else if (Math.round(p * 100) >= lastPct + 10) { lastPct = Math.round(p * 100); out(` ${lastPct}%\n`); }
    });
  } catch (e) {
    log(LOG, "pull failed: " + e);
    if (anim) out("\n");
    await srv.restart(false);
    showErr("can't download the brain", ["e could not reach the model server.", "this one step needs internet. connect, then run e again;", "the download resumes where it stopped."], "E-NET-01");
    return false;
  }
  await srv.restart(false);
  out((anim ? "\n" : "") + " " + hot("[ok]") + " " + t.tag + " ready\n");
  return true;
}

// ---------- chat ----------
class Wrap {
  col = 0; word = ""; constructor(public w: number) { out(" "); }
  put(s: string) {
    for (const ch of s) {
      if (ch === "\n") { this.flush(); this.nl(); }
      else if (/\s/.test(ch)) { this.flush(); if (this.col > 0 && this.col < this.w) { out(" "); this.col++; } }
      else this.word += ch;
    }
  }
  flush() {
    if (!this.word) return;
    let w = this.word.replace(/\*\*|__/g, ""); if (this.col === 0 && w === "*") w = "-";
    this.word = "";
    if (!w) return;
    if (this.col + w.length > this.w && this.col > 0) this.nl();
    out(w); this.col += w.length;
  }
  nl() { out("\n "); this.col = 0; }
  end() { this.flush(); out("\n"); }
}

const SYSTEM = `You are e, a friendly, practical assistant running offline on the user's own computer from a USB drive. You have no internet, no live news and no web access, so say so if asked about current events.
Talk naturally, like a normal conversation. Keep answers short unless the user asks for detail. Don't assume the user is in danger or having an emergency unless they say so.`;

async function chat(model: string, idx: Index): Promise<"models" | "quit"> {
  const { cols } = termSize(); const w = Math.min(cols - 2, 78);
  const header = () => out("\n " + accent("e") + dim(` ${G.dot} ${model} ${G.dot} offline`) + "\n " + muted(G.h.repeat(w - 1)) + "\n");
  header();
  out(" " + dim(`type anything ${G.dot} /models /clear /quit`) + "\n");
  let history: { role: string; content: string }[] = [];
  let lastUser = "";
  for (;;) {
    out("\n");
    const prompt = accent("e> ");
    const q = await input!.readLine(prompt);
    if (q === null || q === "\x03") return "quit";
    if (!input!.tty) out(prompt + q + "\n");
    const text = q.trim(); if (!text) continue;
    if (text === "/quit" || text === "/exit" || text === "/q") return "quit";
    if (text === "/models") return "models";
    if (text === "/clear") { history = []; lastUser = ""; if (isTTY) out("\x1b[2J\x1b[H"); header(); continue; }
    if (text === "/help") { out(" " + dim("/models pick another brain  /clear new chat  /quit") + "\n"); continue; }
    if (text.startsWith("/")) { out(" " + dim("unknown command. try /help") + "\n"); continue; }

    if (input!.tty) { out("\x1b[1A\r\x1b[K"); }
    out("\n " + dim("you") + "\n");
    if (input!.tty) out(" " + bg(C.panel) + fg(C.accent) + G.bar + fg(C.fg) + " " + padR(text, Math.max(0, w - 4)) + RST + "\n"); else out(" " + G.bar + " " + text + "\n");
    out("\n " + accent("e") + "\n");

    const sys = SYSTEM, userMsg = text; // knowledge-base retrieval removed (his call, 11/01: it answered casual chat with CPR steps)
    const ac = new AbortController();
    input!.onCtrlC = () => ac.abort();
    let spin: ReturnType<typeof setInterval> | null = null, si = 0, started = false, wrap: Wrap | null = null, answer = "", stats = "";
    const label = "thinking...";
    if (anim) {
      const tick = () => {
        let s = ""; const hl = (si / 2) % (label.length + 6) - 3;
        for (let i = 0; i < label.length; i++) s += (Math.abs(i - hl) < 2 ? fg(C.fg) : fg(C.dim)) + label[i];
        out("\r\x1b[K " + accent(G.spin[si++ % G.spin.length]) + " " + s + RST);
      };
      hideCursor(); tick(); spin = setInterval(tick, 80);
    }
    try {
      for await (const o of srv.chat(model, [{ role: "system", content: sys }, ...history.slice(-8), { role: "user", content: userMsg }], ac.signal)) {
        const tok: string = o.message?.content || "";
        if (tok && !started) { started = true; if (spin) { clearInterval(spin); spin = null; out("\r\x1b[K"); showCursor(); } wrap = new Wrap(w - 2); }
        if (tok) { wrap!.put(tok); answer += tok; }
        if (o.done && o.eval_count && o.eval_duration) stats = (o.eval_count / (o.eval_duration / 1e9)).toFixed(1) + " tok/s";
      }
      if (spin) { clearInterval(spin); spin = null; out("\r\x1b[K"); }
      if (wrap) wrap.end(); else out(" " + dim("(no answer)") + "\n");
      if (stats) out(" " + dim(stats) + "\n");
      history.push({ role: "user", content: text }, { role: "assistant", content: answer }); lastUser = text;
    } catch (e: any) {
      if (spin) { clearInterval(spin); spin = null; out("\r\x1b[K"); }
      if (ac.signal.aborted) { if (wrap) wrap.end(); out(" " + dim("[stopped]") + "\n"); if (answer) history.push({ role: "user", content: text }, { role: "assistant", content: answer }); }
      else { log(LOG, "chat error: " + (e?.stack || e)); showErr("e lost the model", ["the local model stopped answering.", "try again; if it keeps happening run e again."], "E-CHAT-01"); }
    } finally { input!.onCtrlC = null; showCursor(); }
  }
}
const tokensOf = (s: string) => s.split(/\s+/).filter(Boolean).length;

// ---------- main ----------
async function main() {
  if (has("--version")) { console.log("e " + VERSION); return; }
  if (has("--logo")) { buildE(); console.log(frame(FREEZE_Y, FREEZE_X, BIG).join("\n")); return; }
  if (has("--help") || has("-h")) { console.log("e [--no-anim] [--model <tag>] [--version]\nnormally started by e.sh (mac/linux) or e.bat (windows)."); return; }
  input = new Input();
  termInit();
  const st = { runtime: "starting" };
  process.env.NO_PROXY = "127.0.0.1,localhost"; // our own calls to the local server must never go through a proxy
  const ready = srv.start(modelsOnDisk(HOME).length === 0).then(() => { st.runtime = "ready"; }, (e) => { st.runtime = "failed"; log(LOG, String(e)); throw e; });
  ready.catch(() => {});
  await splash(ready, st);
  try { await ready; } catch (e: any) {
    showErr("the runtime didn't start", [String(e.message || e).replace(/^E-[A-Z]+-\d+ /, ""), "run e.sh / e.bat again to repeat setup."], String(e.message || "").slice(0, 10) || "E-RUNTIME-02");
    quit(1);
  }
  const idx = new Index(path.join(HOME, "knowledge"));
  let installed = new Set((await srv.tags()).map((m) => m.name.replace(/:latest$/, "")));
  let model: string | undefined = opt("--model") || cfg().model;
  let wantPick = false;
  for (;;) {
    if (!model || !installed.has(model) || wantPick) {
      if (!model && !wantPick && !input.tty) model = recommended(ram()).tag;
      else if (!opt("--model") || wantPick) {
        if (wantPick && model) await srv.unload(model); // free the loaded model so the RAM numbers are honest
        const t = await pick(installed);
        if (!t) { out(" " + dim("ok. nothing changed.") + "\n"); if (wantPick && model && installed.has(model)) { wantPick = false; continue; } quit(0); }
        model = t.tag;
      }
      wantPick = false;
      if (!(await ensureModel(TIERS.find((x) => x.tag === model)!))) { model = undefined; if (!input.tty) quit(1); if (opt("--model")) quit(1); continue; }
      installed = new Set((await srv.tags()).map((m) => m.name.replace(/:latest$/, "")));
    }
    saveCfg({ model });
    const r = await chat(model!, idx);
    if (r === "quit") break;
    wantPick = true;
  }
  out("\n " + dim("bye. e stopped, nothing is running.") + "\n");
  quit(0);
}
main().catch((e) => { log(LOG, "fatal: " + (e?.stack || e)); showErr("something went wrong", ["e hit an unexpected problem and stopped.", "details were saved to e.log on the drive."], "E-BUG-02"); quit(1); });
