// Spinning 3D ASCII "e". Port of buildE()/frame() from design-preview.html (same math, same ramp, same light).
import zlib from "node:zlib";
import { GLYPH_W, GLYPH_H, GLYPH_B64 } from "./glyph";
import { grad, mode, RST } from "./ui";

const RAMP = ".,-~:;=+x!*#$@";
const CAM = 4.2, ASP = 0.6, NK = 16;
export const FREEZE_Y = -0.12, FREEZE_X = 0.18;
let P: Float32Array, N: Float32Array, LEN = 0;

export function buildE() {
  if (LEN) return;
  const d = zlib.inflateSync(Buffer.from(GLYPH_B64, "base64"));
  const W = GLYPH_W, H = GLYPH_H, R = 70, m = Math.max(W, H), cs = m / R;
  const GW = Math.ceil(W / cs), GH = Math.ceil(H / cs);
  const A: Float32Array[] = [];
  for (let y = 0; y < GH; y++) {
    A.push(new Float32Array(GW));
    for (let x = 0; x < GW; x++) {
      let s = 0, n = 0;
      for (let yy = 0; yy < cs; yy += 1) for (let xx = 0; xx < cs; xx += 1) {
        const px = Math.floor(x * cs + xx), py = Math.floor(y * cs + yy);
        if (px < W && py < H) { s += d[py * W + px] / 255; n++; }
      }
      A[y][x] = n ? s / n : 0;
    }
  }
  const at2 = (a: Float32Array[], x: number, y: number) => (x < 0 || y < 0 || x >= GW || y >= GH ? 0 : a[y][x]);
  const B = A.map((r, y) => Array.from(r, (_, x) => {
    let s = 0; for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) s += at2(A, x + i, y + j); return s / 9;
  }));
  const Bf = B.map((r) => Float32Array.from(r));
  const pts: number[] = [], nrm: number[] = [];
  const T = 0.55, L = 22, half = GW / 2, halfh = GH / 2, u = 2 / Math.max(GW, GH);
  for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
    if (A[y][x] < 0.5) continue;
    const wx = (x - half) * u, wy = -(y - halfh) * u;
    const gx = at2(Bf, x + 1, y) - at2(Bf, x - 1, y), gy = at2(Bf, x, y + 1) - at2(Bf, x, y - 1);
    const edge = at2(A, x - 1, y) < 0.5 || at2(A, x + 1, y) < 0.5 || at2(A, x, y - 1) < 0.5 || at2(A, x, y + 1) < 0.5;
    const gl = Math.hypot(gx, gy) || 1;
    const tilt = Math.min(1, Math.hypot(gx, gy) * 3);
    for (const [sgn, z] of [[1, T / 2], [-1, -T / 2]]) {
      const nz = sgn * (1 - tilt * 0.6), nx = (-gx / gl) * tilt * 0.6, ny = (gy / gl) * tilt * 0.6, nl = Math.hypot(nx, ny, nz);
      pts.push(wx, wy, z); nrm.push(nx / nl, ny / nl, nz / nl);
    }
    if (edge) for (let k = 1; k < L; k++) { pts.push(wx, wy, (k / L - 0.5) * T); nrm.push(-gx / gl, gy / gl, 0); }
  }
  P = Float32Array.from(pts); N = Float32Array.from(nrm); LEN = pts.length / 3;
}

let LX = -0.35, LY = 0.5, LZ = 0.8;
{ const ll = Math.hypot(LX, LY, LZ); LX /= ll; LY /= ll; LZ /= ll; }

export interface Size { cols: number; rows: number; sc: number }
export const BIG: Size = { cols: 44, rows: 24, sc: 10.16 };
export const SMALL: Size = { cols: 30, rows: 17, sc: 6.93 };

/** Returns `rows` strings, each exactly `cols` visible chars wide (colored in truecolor/256). */
export function frame(ay: number, ax: number, s: Size = BIG): string[] {
  buildE();
  const { cols: COLS, rows: ROWS, sc: SC } = s;
  const zb = new Float32Array(COLS * ROWS).fill(-1e9), has = new Uint8Array(COLS * ROWS), lm = new Float32Array(COLS * ROWS);
  const cy = Math.cos(ay), sy = Math.sin(ay), cx = Math.cos(ax), sx = Math.sin(ax);
  for (let i = 0; i < LEN; i++) {
    const px = P[i * 3], py = P[i * 3 + 1], pz = P[i * 3 + 2], nx = N[i * 3], ny = N[i * 3 + 1], nz = N[i * 3 + 2];
    const x1 = px * cy + pz * sy, z1 = -px * sy + pz * cy, nx1 = nx * cy + nz * sy, nz1 = -nx * sy + nz * cy;
    const y2 = py * cx - z1 * sx, z2 = py * sx + z1 * cx, ny2 = ny * cx - nz1 * sx, nz2 = ny * sx + nz1 * cx;
    if (nz2 <= 0) continue;
    const k = CAM / (CAM - z2), c = Math.round(COLS / 2 + (x1 * SC * k) / ASP), r = Math.round(ROWS / 2 - y2 * SC * k);
    if (c < 0 || c >= COLS || r < 0 || r >= ROWS) continue;
    const id = r * COLS + c; if (z2 <= zb[id]) continue; zb[id] = z2;
    has[id] = 1; lm[id] = Math.max(0, nx1 * LX + ny2 * LY + nz2 * LZ);
  }
  const cc: string[] = []; for (let q = 0; q < NK; q++) cc.push(grad(q / (NK - 1)));
  const rowsOut: string[] = [];
  for (let r = 0; r < ROWS; r++) {
    let line = "", rc = -1;
    for (let c = 0; c < COLS; c++) {
      const id = r * COLS + c;
      if (!has[id]) { line += " "; continue; }
      const l2 = Math.min(1, lm[id] * 1.1), idx = Math.min(RAMP.length - 1, Math.floor(l2 * RAMP.length)), kk = Math.min(NK - 1, Math.floor(l2 * NK));
      if (mode !== "none" && kk !== rc) { line += cc[kk]; rc = kk; }
      line += RAMP[idx];
    }
    rowsOut.push(mode === "none" ? line : line + RST);
  }
  return rowsOut;
}
