// Palette + drawing helpers. The ONLY colors: brown + orange->yellow (see Design North Star).
import fs from "node:fs";
export type Mode = "true" | "256" | "16" | "none";
const env = process.env;
export const isTTY = !!process.stdout.isTTY;

function detect(): Mode {
  const f = env.E_COLOR;
  if (f === "true" || f === "256" || f === "16" || f === "none") return f;
  if (!isTTY || ("NO_COLOR" in env && env.NO_COLOR !== "") || env.TERM === "dumb") return "none";
  const ct = (env.COLORTERM || "").toLowerCase();
  if (ct.includes("truecolor") || ct.includes("24bit")) return "true";
  if (env.WT_SESSION || ["iTerm.app", "vscode", "WezTerm", "ghostty", "Hyper"].includes(env.TERM_PROGRAM || "")) return "true";
  if (env.TERM_PROGRAM === "Apple_Terminal") return "256";
  if ((env.TERM || "").includes("256")) return "256";
  if (process.platform === "win32") return "256";
  return "16";
}
export const mode: Mode = detect();
export const utf8: boolean =
  process.platform === "win32" ? !!(env.WT_SESSION || env.TERM_PROGRAM || env.E_UTF8 === "1") && env.E_ASCII !== "1"
    : /utf-?8/i.test(`${env.LC_ALL || ""}${env.LC_CTYPE || ""}${env.LANG || ""}`) && env.E_ASCII !== "1";

type RGB = [number, number, number];
export const C = {
  bg: [11, 8, 6, 233] as const, panel: [22, 16, 11, 234] as const, border: [58, 42, 30, 237] as const,
  fg: [246, 235, 221, 255] as const, dim: [140, 123, 107, 245] as const, muted: [92, 77, 64, 240] as const,
  accent: [255, 176, 32, 214] as const, yellow: [255, 228, 92, 221] as const, amber: [255, 196, 0, 214] as const,
};
type Col = readonly [number, number, number, number];
export const SGR_BG = mode === "256" && env.TERM_PROGRAM === "Apple_Terminal" && env.E_NO_BG !== "1"; // terminals with no OSC 11: paint the brown ourselves
export const RST = mode === "none" ? "" : SGR_BG ? "\x1b[0m\x1b[48;5;233m\x1b[38;5;255m" : "\x1b[0m";
export function fg(c: Col): string {
  if (mode === "true") return `\x1b[38;2;${c[0]};${c[1]};${c[2]}m`;
  if (mode === "256") return `\x1b[38;5;${c[3]}m`;
  if (mode === "16") return c === C.accent || c === C.yellow || c === C.amber ? "\x1b[93m" : "";
  return "";
}
export function bg(c: Col): string {
  if (mode === "true") return `\x1b[48;2;${c[0]};${c[1]};${c[2]}m`;
  if (mode === "256") return `\x1b[48;5;${c[3]}m`;
  return "";
}
export const paint = (c: Col, s: string) => (mode === "none" ? s : fg(c) + s + RST);
export const dim = (s: string) => paint(C.dim, s);
export const muted = (s: string) => paint(C.muted, s);
export const accent = (s: string) => paint(C.accent, s);
export const hot = (s: string) => paint(C.yellow, s);

const stops: RGB[] = [[255, 77, 0], [255, 138, 0], [255, 196, 0], [255, 228, 92]];
const at = [0, 0.35, 0.7, 1];
export function gradRGB(t: number): RGB {
  t = Math.max(0, Math.min(1, t));
  for (let i = 1; i < 4; i++) if (t <= at[i]) {
    const k = (t - at[i - 1]) / (at[i] - at[i - 1]), a = stops[i - 1], b = stops[i];
    return [0, 1, 2].map((j) => Math.round(a[j] + (b[j] - a[j]) * k)) as RGB;
  }
  return stops[3];
}
export function grad(t: number): string {
  if (mode === "true") { const c = gradRGB(t); return `\x1b[38;2;${c[0]};${c[1]};${c[2]}m`; }
  if (mode === "256") return `\x1b[38;5;${t < 0.2 ? 202 : t < 0.5 ? 208 : t < 0.8 ? 214 : 221}m`;
  if (mode === "16") return "\x1b[93m";
  return "";
}
export function gradText(s: string): string {
  if (mode === "none") return s;
  const n = Math.max(1, s.length - 1);
  let out = "";
  for (let i = 0; i < s.length; i++) out += grad(i / n) + s[i];
  return out + RST;
}
export const vlen = (s: string) => [...s.replace(/\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07/g, "")].length;
export const padR = (s: string, w: number) => s + " ".repeat(Math.max(0, w - vlen(s)));

export const G = utf8
  ? { tl: "╭", tr: "╮", bl: "╰", br: "╯", h: "─", v: "│", bar: "▌", fill: "█", empty: "░", spin: "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏", dot: "·", arrow: "->" }
  : { tl: "+", tr: "+", bl: "+", br: "+", h: "-", v: "|", bar: "|", fill: "#", empty: ".", spin: "|/-\\", dot: "-", arrow: "->" };

/** Rounded box. gradientBorder: ember->yellow along the top edge, stops by position on the others. */
export function box(lines: string[], inner: number, title = "", gradientBorder = false): string[] {
  const edge = (ch: string, t: number) => (mode === "none" ? ch : (gradientBorder ? grad(t) : fg(C.border)) + ch + RST);
  const head = title ? ` ${title} ` : "";
  const topChars = G.tl + G.h + head + G.h.repeat(Math.max(0, inner - 1 - head.length)) + G.tr;
  const total = topChars.length;
  let top = "";
  for (let i = 0; i < total; i++) {
    const inTitle = title && i >= 2 && i < 2 + head.length;
    if (inTitle) top += mode === "none" ? topChars[i] : (gradientBorder ? grad(i / (total - 1)) : fg(C.fg)) + topChars[i] + RST;
    else top += edge(topChars[i], i / (total - 1));
  }
  const out = [top];
  lines.forEach((l, i) => {
    const t = lines.length > 1 ? 0.1 + 0.9 * (i / (lines.length - 1)) : 0.5;
    out.push(edge(G.v, t) + padR(l, inner) + edge(G.v, t));
  });
  let bot = "";
  const bc = G.bl + G.h.repeat(inner) + G.br;
  for (let i = 0; i < bc.length; i++) bot += edge(bc[i], i / (bc.length - 1));
  out.push(bot);
  return out;
}

export function termSize() { return { cols: process.stdout.columns || 80, rows: process.stdout.rows || 24 }; }
export const out = (s: string) => { process.stdout.write(s); };
export const hideCursor = () => isTTY && out("\x1b[?25l");
export const showCursor = () => isTTY && out("\x1b[?25h");
export function log(file: string, msg: string) { try { fs.appendFileSync(file, `[${new Date().toISOString()}] ${msg}\n`); } catch {} }
