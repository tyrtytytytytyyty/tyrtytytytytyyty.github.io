#!/usr/bin/env bash
# Build the e binaries (needs bun). Output: ../dist/ and ../checksums.txt
set -e
cd "$(dirname "$0")"; mkdir -p ../dist; : > ../checksums.txt
for t in darwin-arm64 darwin-x64 linux-x64 linux-arm64 windows-x64; do
  ext=""; [ "$t" = windows-x64 ] && ext=".exe"
  out="../dist/e-$t$ext"
  bun build main.ts --compile --minify --target=bun-$t --outfile="$out"
  (cd ../dist && shasum -a 256 "e-$t$ext" | sed 's/  / /' >> ../checksums.txt)
done
rm -f .*.bun-build; ls -l ../dist
