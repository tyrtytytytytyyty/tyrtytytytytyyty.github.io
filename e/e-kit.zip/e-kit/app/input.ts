// Raw-mode keys + a small line editor. Falls back to line reads when stdin is a pipe.
import { out, isTTY } from "./ui";

export class Input {
  tty = !!process.stdin.isTTY;
  private q: string[] = []; private waiters: ((k: string | null) => void)[] = [];
  private ended = false; private buf = ""; hist: string[] = [];
  onCtrlC: (() => void) | null = null;
  constructor() {
    if (this.tty) { process.stdin.setRawMode(true); }
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", (d: string) => this.tty ? this.keys(d) : this.lines(d));
    process.stdin.on("end", () => { this.ended = true; if (!this.tty && this.buf) { this.push(this.buf); this.buf = ""; } this.waiters.splice(0).forEach((w) => w(null)); });
    process.stdin.resume();
  }
  close() { try { if (this.tty) process.stdin.setRawMode(false); } catch {} process.stdin.pause(); }
  private push(k: string) {
    if (k === "\x03" && this.onCtrlC) { this.onCtrlC(); return; }
    const w = this.waiters.shift(); if (w) w(k); else this.q.push(k);
  }
  private lines(d: string) {
    this.buf += d; let i: number;
    while ((i = this.buf.indexOf("\n")) >= 0) { this.push(this.buf.slice(0, i).replace(/\r$/, "")); this.buf = this.buf.slice(i + 1); }
  }
  private keys(d: string) {
    let i = 0;
    while (i < d.length) {
      if (d[i] === "\x1b") {
        let j = i + 1;
        if (d[j] === "[") { j++; while (j < d.length && !/[A-Za-z~]/.test(d[j])) j++; j++; }
        else if (d[j] === "O") j += 2; else j++;
        this.push(d.slice(i, j)); i = j;
      } else { const cp = String.fromCodePoint(d.codePointAt(i)!); this.push(cp); i += cp.length; }
    }
  }
  next(): Promise<string | null> {
    if (this.q.length) return Promise.resolve(this.q.shift()!);
    if (this.ended) return Promise.resolve(null);
    return new Promise((r) => this.waiters.push(r));
  }
  /** Returns the next key token (TTY) or whole line (pipe). null = input closed. */
  key() { return this.next(); }
  /** Edit a line. Returns null on EOF / double ctrl+c quit request ("\x03"). */
  async readLine(prompt: string, _n = 0): Promise<string | null> {
    if (!this.tty) { const l = await this.next(); return l; }
    let s: string[] = [], pos = 0, hi = this.hist.length, lastC = 0;
    const draw = () => { out("\r\x1b[K" + prompt + s.join("") + (s.length - pos ? `\x1b[${s.length - pos}D` : "")); };
    draw();
    for (;;) {
      const k = await this.next(); if (k === null) return null;
      if (k === "\r" || k === "\n") { out("\n"); const line = s.join(""); if (line.trim()) this.hist.push(line); return line; }
      if (k === "\x03") { if (Date.now() - lastC < 2000) { out("\n"); return "\x03"; } lastC = Date.now(); s = []; pos = 0; out("\r\x1b[K" + prompt + "\x1b7  ctrl+c again to quit\x1b8"); continue; }
      if (k === "\x04") { if (!s.length) return null; }
      else if (k === "\x7f" || k === "\b") { if (pos) { s.splice(pos - 1, 1); pos--; } }
      else if (k === "\x1b[3~") { s.splice(pos, 1); }
      else if (k === "\x1b[D" || k === "\x02") pos = Math.max(0, pos - 1);
      else if (k === "\x1b[C" || k === "\x06") pos = Math.min(s.length, pos + 1);
      else if (k === "\x1b[H" || k === "\x01" || k === "\x1bOH") pos = 0;
      else if (k === "\x1b[F" || k === "\x05" || k === "\x1bOF") pos = s.length;
      else if (k === "\x15") { s = s.slice(pos); pos = 0; }
      else if (k === "\x17") { let p = pos; while (p > 0 && s[p - 1] === " ") p--; while (p > 0 && s[p - 1] !== " ") p--; s.splice(p, pos - p); pos = p; }
      else if (k === "\x1b[A") { if (hi > 0) { hi--; s = [...this.hist[hi]]; pos = s.length; } }
      else if (k === "\x1b[B") { if (hi < this.hist.length - 1) { hi++; s = [...this.hist[hi]]; } else { hi = this.hist.length; s = []; } pos = s.length; }
      else if (k.startsWith("\x1b") || k < " ") continue;
      else { const ch = [...k]; s.splice(pos, 0, ...ch); pos += ch.length; }
      draw();
    }
  }
}
void isTTY;
