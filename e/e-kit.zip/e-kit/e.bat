@echo off
rem e - offline AI on a stick. Windows launcher: double-click this file.
rem First run = one-time setup (needs internet). Later runs = chat (no internet).
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0e.ps1" %*
if errorlevel 1 (
  echo.
  echo   e stopped with a problem. details are above and in e.log.
  pause
)
