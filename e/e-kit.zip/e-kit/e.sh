#!/usr/bin/env bash
# e - offline AI on a stick. Mac + Linux launcher.
# First run = one-time setup (needs internet). Every run after that = chat (no internet).
set -u
KIT="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
BASE="${E_BIN_BASE:-https://tyycc.com/e/bin}"          # where the per-OS e binary lives
OLLAMA_VERSION="${E_OLLAMA_VERSION:-v0.40.13}"           # pinned, tested release
OLLAMA_URL="https://github.com/ollama/ollama/releases/download/${OLLAMA_VERSION}"

say()  { printf '  %s\n' "$*"; }
fail() { printf '\n  [x] %s\n\n' "$*" >&2; exit 1; }

case "$(uname -s)" in
  Darwin) OS=darwin ;;
  Linux)  OS=linux ;;
  *) fail "this script is for mac and linux. on windows, double-click e.bat." ;;
esac
case "$(uname -m)" in
  arm64|aarch64) ARCH=arm64; OARCH=arm64 ;;
  x86_64|amd64)  ARCH=x64;   OARCH=amd64 ;;
  *) fail "unsupported cpu: $(uname -m)" ;;
esac

EBIN="$KIT/bin/e-$OS-$ARCH"
ODIR="$KIT/bin/ollama-$OS-$ARCH"
mkdir -p "$KIT/bin" "$KIT/models" "$KIT/data"

have() { command -v "$1" >/dev/null 2>&1; }
sha() { if have shasum; then shasum -a 256 "$1" | cut -d' ' -f1; else sha256sum "$1" | cut -d' ' -f1; fi; }
find_ollama() { for p in "$ODIR/ollama" "$ODIR/bin/ollama"; do [ -x "$p" ] && return 0; done; return 1; }
download() { # url dest
  have curl || fail "curl is needed for setup (it ships with mac and most linux)."
  curl -L --fail --retry 3 -C - --progress-bar -o "$2.part" "$1" || fail "download failed: $1
      check your internet, then run e.sh again (it resumes)."
  mv "$2.part" "$2"
}

# ---------- 1. runtime (ollama), one time ----------
if ! find_ollama; then
  say "setup 1/2: downloading the runtime (ollama $OLLAMA_VERSION). this needs internet, once."
  if [ "$OS" = darwin ]; then ASSET="ollama-darwin.tgz"; else ASSET="ollama-linux-$OARCH.tar.zst"; fi
  if [ "$OS" = linux ] && ! have zstd; then fail "linux needs zstd to unpack the runtime. install it (for example: sudo apt install zstd) and run e.sh again."; fi
  TMP="$KIT/bin/.dl"; mkdir -p "$TMP"
  download "$OLLAMA_URL/$ASSET" "$TMP/$ASSET"
  download "$OLLAMA_URL/sha256sum.txt" "$TMP/sha256sum.txt" 2>/dev/null
  WANT="$(grep " \(\./\)\?$ASSET\$" "$TMP/sha256sum.txt" 2>/dev/null | head -1 | cut -d' ' -f1)"
  if [ -n "$WANT" ]; then
    [ "$(sha "$TMP/$ASSET")" = "$WANT" ] || { rm -f "$TMP/$ASSET"; fail "checksum mismatch on the runtime download. run e.sh again."; }
    say "runtime checksum ok."
  else say "(no checksum list found for the runtime; skipping that check)"; fi
  rm -rf "$ODIR"; mkdir -p "$ODIR"
  if [ "$OS" = darwin ]; then tar -xzf "$TMP/$ASSET" -C "$ODIR" || fail "could not unpack the runtime."
  else zstd -dc "$TMP/$ASSET" | tar -x -C "$ODIR" || fail "could not unpack the runtime."; fi
  rm -rf "$TMP"
  find_ollama || fail "runtime unpacked but 'ollama' was not found inside it."
  chmod +x "$ODIR/ollama" "$ODIR/bin/ollama" 2>/dev/null
fi

# ---------- 2. the e chat program, one time ----------
if [ ! -x "$EBIN" ]; then
  say "setup 2/2: getting the e program for $OS-$ARCH (about 60 MB)."
  if [ -f "$KIT/dist/e-$OS-$ARCH" ]; then cp "$KIT/dist/e-$OS-$ARCH" "$EBIN"      # offline / sneakernet copy
  else download "$BASE/e-$OS-$ARCH" "$EBIN"; fi
  WANT="$(grep " e-$OS-$ARCH\$" "$KIT/checksums.txt" 2>/dev/null | head -1 | cut -d' ' -f1)"
  if [ -n "$WANT" ] && [ "$(sha "$EBIN")" != "$WANT" ]; then rm -f "$EBIN"; fail "checksum mismatch on the e program. run e.sh again, or re-download the kit."; fi
  chmod +x "$EBIN"
fi

# ---------- mac: unsigned binary / quarantine ----------
if [ "$OS" = darwin ]; then
  xattr -dr com.apple.quarantine "$KIT/bin" 2>/dev/null     # only set if the kit came through a browser
  codesign --force --sign - "$EBIN" >/dev/null 2>&1          # ad-hoc signature so macOS will run it
fi

export E_HOME="$KIT"
exec "$EBIN" "$@"
