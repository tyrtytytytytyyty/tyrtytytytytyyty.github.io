# e

**An AI that still works when the wifi doesn't.** e turns any USB drive into an offline AI you chat with in the terminal. No account, no subscription.

license: MIT, open source (see `LICENSE`; source is in `app/`). Ollama is MIT too; the models keep their own licenses (Gemma Terms of Use, Llama 3.2 Community License) and download from their official sources.

It works offline **after a one-time download**. Bigger models need more RAM. e has no live news and no web access, and it is not a substitute for emergency services (call 911).

```
e> how long should I boil water
 According to the notes, you should boil water for 1 minute ... 3 minutes above 6,500 feet.
 21 tok/s · notes used: water.md > how to boil water (best method)
```

## what you need

- a computer: Windows 10/11, a Mac (Apple silicon or Intel), or Linux (64-bit)
- **8 GB RAM** for the default brain (4 GB can run the tiny one, 16 GB+ for the big one)
- a USB drive or folder with room: **mac ~1 GB + the brain** (0.8 / 2.0 / 4.9 GB). **Windows and Linux: plan on 8 GB or more**, because the official runtime bundles graphics-card libraries (about a 1.6 GB download, several GB unpacked)
- internet **once**, for setup. After that you can turn wifi off and unplug

## put it on a drive

1. Format the drive **exFAT** (works on Windows, Mac and Linux) or NTFS/ext4. **Not FAT32**: the big brain is a single file over 4 GB and FAT32 cannot hold it.
2. Unzip this kit so you have a folder called `e-kit` on the drive (or anywhere on your computer).
3. Run it from there (below). Setup downloads into the same folder, so the whole thing stays portable.

Run the first time on the computer you are setting up. Later you can plug the drive into any other machine of the same kind (Mac, Windows or Linux each need their own one-time setup, run once per OS, and all three share the same `models/` folder).

## first run (setup, needs internet once)

### Mac

Open Terminal, then:

```
cd /path/to/e-kit
bash e.sh
```

Tip: type `cd ` then drag the `e-kit` folder into the Terminal window. Next time: `bash e.sh` again. It starts the chat straight away.

**If macOS blocks it** ("cannot be opened because the developer cannot be verified"): e is not signed with an Apple developer certificate. e.sh already removes the download mark and signs it locally, so this normally does not appear. If it does, run `xattr -dr com.apple.quarantine /path/to/e-kit`, or open System Settings > Privacy & Security and click **Open Anyway**.

### Linux

```
cd /path/to/e-kit
bash e.sh
```

Needs `curl`, `tar` and `zstd` (`sudo apt install zstd` on Debian/Ubuntu; `sudo dnf install zstd` on Fedora).

### Windows

Double-click **`e.bat`**. A window opens and runs setup, then the chat.

If Windows says "Windows protected your PC": click **More info**, then **Run anyway** (e is not code-signed). To avoid the message, right-click the zip before unzipping, choose Properties, tick **Unblock**, and unzip after that. Antivirus tools sometimes flag new unsigned programs; e's source is in `app/`.

Prefer a terminal? `powershell -ExecutionPolicy Bypass -File e.ps1`

## what setup does

1. Downloads the official **Ollama** runtime from github.com/ollama/ollama (pinned to a tested version) into `bin/`, and checks its checksum.
2. Downloads the small **e** chat program for your OS from `https://tyycc.com/e/bin/` into `bin/` and checks its checksum (listed in `checksums.txt`).
3. On first launch you pick a brain and e downloads it into `models/`:

| brain | model | download | RAM | notes |
|---|---|---|---|---|
| tiny ~1B | `gemma3:1b` | 0.8 GB | 4 GB+ | fast, a little forgetful |
| default ~3B | `llama3.2:3b` | 2.0 GB | 8 GB+ | **recommended** |
| big ~8B | `llama3.1:8b` | 4.9 GB | 16 GB+ | smartest, slower on old CPUs |
| huge ~27B | `gemma3:27b` | 17 GB | 32 GB+ | near cloud-level, needs a strong machine (untested) |

e measures your RAM and marks what fits. If a choice will not fit you get a "not enough memory" screen with something to try instead; if only *free* memory is short you can close apps, or press `f` to run it anyway.

Model licenses: Gemma is under Google's Gemma Terms of Use; Llama 3.x under the Meta Llama community license. e downloads them from Ollama's official registry; it does not redistribute them.

## using it

You get a spinning 3D ASCII **e** (press any key), then a prompt:

```
e> why does e show up in compound interest?
```

| command | does |
|---|---|
| `/models` | pick or download another brain |
| `/clear` | start a new chat |
| `/quit` | exit (also ctrl+c twice) |

While e is answering, ctrl+c stops that answer. The line under each answer shows its speed. Small models can slip, so double-check anything important.

Options: `--no-anim` (skip the spin), `--model llama3.2:3b` (skip the picker). `NO_COLOR=1` turns colors off.

## where things live

```
e-kit/
  README.md   e.sh   e.bat   e.ps1
  models/      the downloaded brains
  bin/         the runtime and e program, per OS
  data/        small settings file, runtime scratch
  app/         source code for the chat program (bun build --compile)
  e.log        runtime log, for troubleshooting
```

The runtime listens only on `127.0.0.1:11435`, so it never collides with an Ollama you already installed, and it is stopped when e exits. After setup e starts the runtime with its internet access pointed nowhere (a dead proxy), so even its background checks cannot leave your computer. The only time it is allowed online is while you download a brain.

To remove everything: delete the `e-kit` folder.

## troubleshooting

- **"not enough memory"**: close your browser, or pick a smaller brain.
- **download stopped**: run e again. Downloads resume.
- **"checksum mismatch"**: run it again, or download the kit again.
- **anything odd**: look at `e.log` in the kit folder.

---

### for whoever hosts the kit

The zip has no big files. Upload the contents of `dist/` to `https://tyycc.com/e/bin/` (same filenames):

`e-darwin-arm64`, `e-darwin-x64`, `e-linux-x64`, `e-linux-arm64`, `e-windows-x64.exe`

Rebuild with `app/build.sh` (needs bun); it also rewrites `checksums.txt`, which must ship in the zip. Override the host with `E_BIN_BASE=https://...` or drop a binary in `dist/`. Pin a different runtime with `E_OLLAMA_VERSION=v0.x.y`.
