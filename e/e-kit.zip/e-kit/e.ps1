# e - offline AI on a stick. Windows launcher (called by e.bat).
$ErrorActionPreference = 'Stop'
$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path
$Base = if ($env:E_BIN_BASE) { $env:E_BIN_BASE } else { 'https://tyycc.com/e/bin' }   # where the e program lives
$OllamaVersion = if ($env:E_OLLAMA_VERSION) { $env:E_OLLAMA_VERSION } else { 'v0.40.13' }   # pinned, tested release
$OllamaUrl = "https://github.com/ollama/ollama/releases/download/$OllamaVersion"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Say($m)  { Write-Host "  $m" }
function Fail($m) { Write-Host ""; Write-Host "  [x] $m"; Write-Host ""; exit 1 }

# the e program is a 64-bit exe (it also runs on Windows-on-ARM through emulation);
# the runtime we download matches the real CPU.
$native = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
$asset = if ($native -eq 'ARM64') { 'ollama-windows-arm64.zip' } else { 'ollama-windows-amd64.zip' }
$EBin = Join-Path $Kit 'bin\e-windows-x64.exe'
$ODir = Join-Path $Kit 'bin\ollama-windows-x64'
foreach ($d in 'bin','models','data') { New-Item -ItemType Directory -Force -Path (Join-Path $Kit $d) | Out-Null }

function Download($url, $dest) {
  & curl.exe -L --fail --retry 3 -C - --progress-bar -o "$dest.part" $url
  if ($LASTEXITCODE -ne 0) { Fail "download failed: $url`n      check your internet, then run e.bat again (it resumes)." }
  Move-Item -Force "$dest.part" $dest
}

# ---------- 1. runtime (ollama), one time ----------
if (-not (Test-Path (Join-Path $ODir 'ollama.exe'))) {
  Say "setup 1/2: downloading the runtime (ollama $OllamaVersion). this needs internet, once."
  if ($native -ne 'ARM64') { Say "heads up: on windows this download is large (about 1.6 GB, it includes graphics-card libraries). it resumes if it stops." }
  $tmp = Join-Path $Kit 'bin\.dl'; New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  Download "$OllamaUrl/$asset" (Join-Path $tmp $asset)
  try {
    Download "$OllamaUrl/sha256sum.txt" (Join-Path $tmp 'sha256sum.txt')
    $line = (Get-Content (Join-Path $tmp 'sha256sum.txt') | Where-Object { $_ -match "\s\.?/?$([regex]::Escape($asset))$" } | Select-Object -First 1)
    if ($line) {
      $want = ($line -split '\s+')[0].ToLower()
      $got = (Get-FileHash -Algorithm SHA256 (Join-Path $tmp $asset)).Hash.ToLower()
      if ($got -ne $want) { Remove-Item -Force (Join-Path $tmp $asset); Fail "checksum mismatch on the runtime download. run e.bat again." }
      Say "runtime checksum ok."
    }
  } catch { Say "(could not check the runtime checksum; continuing)" }
  if (Test-Path $ODir) { Remove-Item -Recurse -Force $ODir }
  New-Item -ItemType Directory -Force -Path $ODir | Out-Null
  Say "unpacking the runtime (this takes a minute)..."
  & tar.exe -xf (Join-Path $tmp $asset) -C $ODir
  if ($LASTEXITCODE -ne 0) { Fail "could not unpack the runtime." }
  Remove-Item -Recurse -Force $tmp
  if (-not (Test-Path (Join-Path $ODir 'ollama.exe'))) { Fail "runtime unpacked but ollama.exe was not found inside it." }
}

# ---------- 2. the e chat program, one time ----------
if (-not (Test-Path $EBin)) {
  Say "setup 2/2: getting the e program for windows (about 90 MB)."
  $local = Join-Path $Kit 'dist\e-windows-x64.exe'
  if (Test-Path $local) { Copy-Item $local $EBin } else { Download "$Base/e-windows-x64.exe" $EBin }
  $sumFile = Join-Path $Kit 'checksums.txt'
  if (Test-Path $sumFile) {
    $line = Get-Content $sumFile | Where-Object { $_ -match 'e-windows-x64\.exe$' } | Select-Object -First 1
    if ($line) {
      $want = ($line -split '\s+')[0].ToLower()
      if ((Get-FileHash -Algorithm SHA256 $EBin).Hash.ToLower() -ne $want) { Remove-Item -Force $EBin; Fail "checksum mismatch on the e program. run e.bat again, or re-download the kit." }
    }
  }
}

# a kit that came from a browser download carries a "downloaded from the internet" mark that triggers SmartScreen
try { Get-ChildItem $Kit -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.exe','.ps1','.bat' } | Unblock-File -ErrorAction SilentlyContinue } catch {}

$env:E_HOME = $Kit
& $EBin @args
exit $LASTEXITCODE
